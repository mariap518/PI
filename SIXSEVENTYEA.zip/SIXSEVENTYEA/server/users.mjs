// Usuarios, registro, inicio de sesión y sesiones sobre Postgres (tablas app_users y app_sessions).
// - Contraseñas: scrypt con sal (nunca se guardan ni se devuelven en claro).
// - Sesión: cookie httpOnly "sx_sid"; en la base solo se guarda el hash del token.
import crypto from "node:crypto";
import { promisify } from "node:util";
import { ADMIN_CREDENTIALS, ADMIN_CODES, AGENT_CODES } from "./auth-config.mjs";

const scrypt = promisify(crypto.scrypt);
const COOKIE = "sx_sid";
const SESSION_DAYS = 30;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
// Campos del perfil que viven en la columna JSONB `data`
const DATA_FIELDS = ["empresa", "cc", "phone", "city", "position", "points", "lifetimePoints", "reservations", "favorites", "coupons"];

const sha256 = s => crypto.createHash("sha256").update(s).digest();
const safeEqual = (a, b) => crypto.timingSafeEqual(sha256(String(a)), sha256(String(b)));

async function hashPassword(pw) {
  const salt = crypto.randomBytes(16);
  const hash = await scrypt(pw, salt, 64);
  return `scrypt$${salt.toString("base64")}$${hash.toString("base64")}`;
}
async function verifyPassword(pw, stored) {
  if (typeof stored !== "string" || !stored.startsWith("scrypt$")) return false;
  const [, s, h] = stored.split("$");
  const hash = Buffer.from(h, "base64");
  const test = await scrypt(pw, Buffer.from(s, "base64"), hash.length);
  return crypto.timingSafeEqual(test, hash);
}

class HttpError extends Error {
  constructor(status, message, field) { super(message); this.status = status; this.field = field; }
}

const toUser = row => ({ ...row.data, id: row.id, name: row.name, email: row.email, username: row.username ?? undefined, role: row.role });

const cookies = req => Object.fromEntries((req.headers.cookie ?? "").split(";").map(c => c.trim().split("=")).filter(p => p[0]).map(([k, ...v]) => [k, decodeURIComponent(v.join("="))]));

function setCookie(req, res, value, maxAgeSec) {
  const secure = req.secure || req.headers["x-forwarded-proto"] === "https";
  res.append("Set-Cookie", `${COOKIE}=${encodeURIComponent(value)}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${maxAgeSec}${secure ? "; Secure" : ""}`);
}

// Freno básico contra adivinar contraseñas: 8 fallos por IP+usuario cada 10 minutos
const fails = new Map();
const failKey = (req, id) => `${req.ip}|${id}`;
function checkLimit(req, id) {
  const f = fails.get(failKey(req, id));
  if (f && f.until > Date.now() && f.count >= 8) throw new HttpError(429, "Demasiados intentos. Espera unos minutos e inténtalo de nuevo.");
}
function noteFail(req, id) {
  const k = failKey(req, id), f = fails.get(k);
  if (!f || f.until < Date.now()) fails.set(k, { count: 1, until: Date.now() + 10 * 60_000 });
  else f.count++;
}

export function registerUsers(app, pool) {
  const wrap = fn => (req, res) =>
    fn(req, res).catch(err => {
      if (err instanceof HttpError) return res.status(err.status).json({ error: err.message, field: err.field });
      if (err?.code === "23505") return res.status(409).json({ error: "Ese correo o usuario ya está registrado.", field: "email" });
      console.error(err);
      res.status(500).json({ error: "Error del servidor" });
    });

  async function startSession(req, res, userId) {
    const token = crypto.randomBytes(32).toString("base64url");
    await pool.query(`DELETE FROM app_sessions WHERE expires_at < now()`);
    await pool.query(`INSERT INTO app_sessions (token_hash, user_id, expires_at) VALUES ($1, $2, now() + ($3 || ' days')::interval)`,
      [sha256(token).toString("hex"), userId, String(SESSION_DAYS)]);
    setCookie(req, res, token, SESSION_DAYS * 86400);
  }

  async function sessionUser(req) {
    const token = cookies(req)[COOKIE];
    if (!token) return null;
    const { rows } = await pool.query(
      `SELECT u.* FROM app_sessions s JOIN app_users u ON u.id = s.user_id WHERE s.token_hash = $1 AND s.expires_at > now()`,
      [sha256(token).toString("hex")]);
    return rows[0] ?? null;
  }

  const requireUser = async req => { const u = await sessionUser(req); if (!u) throw new HttpError(401, "Inicia sesión para continuar."); return u; };

  // ── Registro ──
  app.post("/api/auth/register", wrap(async (req, res) => {
    const b = req.body ?? {};
    const role = b.role === "agente" ? "agente" : "cliente";
    const email = String(b.email ?? "").trim().toLowerCase();
    const username = String(b.username ?? "").trim();
    const name = String(b.name ?? "").trim();
    const empresa = String(b.empresa ?? "");
    if (!EMAIL_RE.test(email)) throw new HttpError(400, "Ingresa un correo válido.", "email");
    if (typeof b.password !== "string" || b.password.length < 6 || b.password.length > 200) throw new HttpError(400, "La contraseña debe tener al menos 6 caracteres.", "password");
    if (String(b.phone ?? "").replace(/\D/g, "").length < 10) throw new HttpError(400, "Ingresa un celular válido (mínimo 10 dígitos).", "phone");
    if (String(b.city ?? "").trim().length < 2) throw new HttpError(400, "Ingresa tu ciudad.", "city");
    if (role === "cliente" && username.length < 3) throw new HttpError(400, "Nombre de usuario debe tener mínimo 3 caracteres.", "username");
    if (role === "agente") {
      if (name.length < 2) throw new HttpError(400, "Ingresa tu nombre completo.", "name");
      if (String(b.cc ?? "").trim().length < 6) throw new HttpError(400, "Ingresa una cédula válida.", "cc");
      if (!(empresa in AGENT_CODES)) throw new HttpError(400, "Empresa no válida.", "empresa");
    }
    if (username && username.toLowerCase() === ADMIN_CREDENTIALS.username.toLowerCase()) throw new HttpError(409, "Ese nombre de usuario no está disponible.", "username");
    const dup = await pool.query(`SELECT 1 FROM app_users WHERE lower(email) = $1 OR (lower(username) = $2 AND $2 <> '') LIMIT 1`, [email, username.toLowerCase()]);
    if (dup.rowCount) throw new HttpError(409, "Ese correo o usuario ya está registrado.", "email");

    const data = { points: 0, lifetimePoints: 0, coupons: [], reservations: [], favorites: [], phone: String(b.phone).trim(), city: String(b.city).trim() };
    if (role === "agente") { data.empresa = empresa; data.cc = String(b.cc).trim(); }
    await pool.query(
      `INSERT INTO app_users (id, name, email, username, role, password_hash, data) VALUES ($1,$2,$3,$4,$5,$6,$7)`,
      [crypto.randomUUID(), role === "cliente" ? username : name, email, username || null, role, await hashPassword(b.password), data]);
    res.status(201).json({ ok: true });
  }));

  // ── Inicio de sesión (agentes y administradores piden además su código) ──
  app.post("/api/auth/login", wrap(async (req, res) => {
    const b = req.body ?? {};
    const identifier = String(b.identifier ?? "").trim();
    const id = identifier.toLowerCase();
    const password = String(b.password ?? "");
    const code = b.code === undefined || b.code === null ? "" : String(b.code);
    if (!id || !password) throw new HttpError(400, "Ingresa tu correo o usuario y tu contraseña.", "email");
    checkLimit(req, id);

    // Administrador
    if (id === ADMIN_CREDENTIALS.username.toLowerCase()) {
      if (!safeEqual(password, ADMIN_CREDENTIALS.password)) { noteFail(req, id); throw new HttpError(401, "Credenciales incorrectas o cuenta no registrada.", "password"); }
      if (!code) return res.status(202).json({ needsCode: "admin" });
      const name = Object.hasOwn(ADMIN_CODES, code) ? ADMIN_CODES[code] : undefined;
      if (!name) { noteFail(req, id); throw new HttpError(403, "Código de acceso inválido.", "code"); }
      const adminId = "admin-" + code;
      await pool.query(
        `INSERT INTO app_users (id, name, email, username, role, data) VALUES ($1,$2,$3,$4,'admin','{"points":0,"reservations":[],"favorites":[]}'::jsonb) ON CONFLICT (id) DO NOTHING`,
        [adminId, name, `admin${code}@sixevent.co`, ADMIN_CREDENTIALS.username]).catch(async e => {
        if (e.code !== "23505") throw e; // el usuario "admin78" ya lo tiene otro administrador: se crea sin ese nombre de usuario
        await pool.query(`INSERT INTO app_users (id, name, email, role, data) VALUES ($1,$2,$3,'admin','{"points":0,"reservations":[],"favorites":[]}'::jsonb) ON CONFLICT (id) DO NOTHING`, [adminId, name, `admin${code}@sixevent.co`]);
      });
      await startSession(req, res, adminId);
      fails.delete(failKey(req, id));
      const { rows: [row] } = await pool.query(`SELECT * FROM app_users WHERE id = $1`, [adminId]);
      return res.json({ user: toUser(row) });
    }

    // Cliente o agente
    const { rows: [row] } = await pool.query(
      `SELECT * FROM app_users WHERE (lower(email) = $1 OR lower(username) = $1) AND role <> 'admin' LIMIT 1`, [id]);
    if (!row || !(await verifyPassword(password, row.password_hash))) { noteFail(req, id); throw new HttpError(401, "Credenciales incorrectas o cuenta no registrada.", "password"); }
    if (row.role === "agente") {
      const need = Object.hasOwn(AGENT_CODES, row.data?.empresa) ? AGENT_CODES[row.data.empresa] : undefined;
      if (!code) return res.status(202).json({ needsCode: "agent", empresa: row.data?.empresa });
      if (!need || !safeEqual(code, need)) { noteFail(req, id); throw new HttpError(403, "Código de acceso inválido para tu empresa.", "code"); }
    }
    await startSession(req, res, row.id);
    fails.delete(failKey(req, id));
    res.json({ user: toUser(row) });
  }));

  // ── Quién soy ──
  app.get("/api/auth/me", wrap(async (req, res) => {
    const row = await sessionUser(req);
    res.json({ user: row ? toUser(row) : null });
  }));

  // ── Actualizar mi perfil / puntos / favoritos / reservas / contraseña ──
  app.put("/api/auth/me", wrap(async (req, res) => {
    const me = await requireUser(req);
    const b = req.body ?? {};
    const cols = {}, data = {};

    if (b.name !== undefined) { const v = String(b.name).trim(); if (v.length < 2) throw new HttpError(400, "Ingresa tu nombre.", "name"); cols.name = v; }
    if (b.email !== undefined) {
      const v = String(b.email).trim().toLowerCase();
      if (!EMAIL_RE.test(v)) throw new HttpError(400, "Ingresa un correo válido.", "email");
      const dup = await pool.query(`SELECT 1 FROM app_users WHERE lower(email) = $1 AND id <> $2`, [v, me.id]);
      if (dup.rowCount) throw new HttpError(409, "Ese correo ya está registrado.", "email");
      cols.email = v;
    }
    for (const k of ["phone", "city", "position"]) if (b[k] !== undefined) data[k] = b[k] === null ? null : String(b[k]).slice(0, 120);
    if (b.empresa !== undefined && me.role === "cliente") data.empresa = b.empresa ? String(b.empresa).slice(0, 120) : null;
    for (const k of ["points", "lifetimePoints"]) if (b[k] !== undefined) { const n = Number(b[k]); if (!Number.isFinite(n) || n < 0) throw new HttpError(400, "Valor no válido."); data[k] = Math.round(n); }
    for (const k of ["favorites", "reservations", "coupons"]) if (b[k] !== undefined) { if (!Array.isArray(b[k]) || b[k].length > 1000) throw new HttpError(400, "Valor no válido."); data[k] = b[k]; }

    if (b.newPassword !== undefined) {
      if (typeof b.newPassword !== "string" || b.newPassword.length < 6) throw new HttpError(400, "La contraseña debe tener al menos 6 caracteres.", "newPassword");
      if (me.password_hash && !(await verifyPassword(String(b.currentPassword ?? ""), me.password_hash))) throw new HttpError(400, "La contraseña actual es incorrecta.", "currentPassword");
      cols.password_hash = await hashPassword(b.newPassword);
    }

    const sets = [], vals = [me.id];
    for (const [k, v] of Object.entries(cols)) { vals.push(v); sets.push(`${k} = $${vals.length}`); }
    if (Object.keys(data).length) { vals.push(data); sets.push(`data = data || $${vals.length}::jsonb`); }
    if (sets.length) await pool.query(`UPDATE app_users SET ${sets.join(", ")} WHERE id = $1`, vals);
    const { rows: [row] } = await pool.query(`SELECT * FROM app_users WHERE id = $1`, [me.id]);
    res.json(toUser(row));
  }));

  // ── Cerrar sesión ──
  app.post("/api/auth/logout", wrap(async (req, res) => {
    const token = cookies(req)[COOKIE];
    if (token) await pool.query(`DELETE FROM app_sessions WHERE token_hash = $1`, [sha256(token).toString("hex")]);
    setCookie(req, res, "", 0);
    res.status(204).end();
  }));

  // ── Lista de usuarios: administrador ve todo; agente solo el id y empresa de los agentes (para el panel) ──
  app.get("/api/users", wrap(async (req, res) => {
    const me = await requireUser(req);
    if (me.role === "admin") {
      const { rows } = await pool.query(`SELECT * FROM app_users ORDER BY created_at`);
      return res.json(rows.map(toUser));
    }
    if (me.role === "agente") {
      const { rows } = await pool.query(`SELECT id, role, data->>'empresa' AS empresa FROM app_users WHERE role = 'agente'`);
      return res.json(rows.map(r => ({ id: r.id, role: r.role, empresa: r.empresa, name: "", email: "" })));
    }
    throw new HttpError(403, "No tienes permiso.");
  }));
}
