// Credenciales y códigos de acceso. ANTES estaban escritos en ts/auth.ts (y viajaban a todos los navegadores).
// Ahora solo viven en el servidor. Cuando quieras, muévelos a .env.local (ADMIN_USER, ADMIN_PASS...).
export const ADMIN_CREDENTIALS = {
  username: process.env.ADMIN_USER ?? "admin78",
  password: process.env.ADMIN_PASS ?? "op98rtUcev",
};

export const ADMIN_CODES = {
  "007": "Samuel Garcia Vinasco",
  "008": "Maria Paula Gamboa Rengifo",
  "009": "Juan Jose Ariza Londoño",
  "010": "Alejandro Garcia Reyes",
};

// empresa → código de acceso de sus agentes
export const AGENT_CODES = {
  Uceva: "900",
  SENA: "567",
};
