import { config } from "dotenv";
import pg from "pg";

config({ path: ".env.local" });

const client = new pg.Client({ connectionString: process.env.DATABASE_URL_UNPOOLED });
await client.connect();

await client.query(`
  CREATE TABLE IF NOT EXISTS events (
    id SERIAL PRIMARY KEY,
    title TEXT NOT NULL,
    category TEXT NOT NULL,
    city TEXT NOT NULL,
    date DATE NOT NULL,
    price INTEGER NOT NULL,
    img TEXT,
    rating NUMERIC(2,1) DEFAULT 5.0,
    created_by TEXT DEFAULT 'system',
    data JSONB NOT NULL DEFAULT '{}'::jsonb
  );

  CREATE TABLE IF NOT EXISTS app_users (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('cliente','agente','admin')),
    password_hash TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
  );
`);

// v17: usuarios completos y sesiones (todo es repetible: se puede ejecutar varias veces)
await client.query(`
  ALTER TABLE app_users ADD COLUMN IF NOT EXISTS username TEXT;
  ALTER TABLE app_users ADD COLUMN IF NOT EXISTS data JSONB NOT NULL DEFAULT '{}'::jsonb;
  CREATE UNIQUE INDEX IF NOT EXISTS app_users_email_lower_key ON app_users (lower(email));
  CREATE UNIQUE INDEX IF NOT EXISTS app_users_username_lower_key ON app_users (lower(username)) WHERE username IS NOT NULL;

  CREATE TABLE IF NOT EXISTS app_sessions (
    token_hash TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES app_users(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    expires_at TIMESTAMPTZ NOT NULL
  );
  CREATE INDEX IF NOT EXISTS app_sessions_user_idx ON app_sessions (user_id);
`);

await client.end();
console.log("Migración OK");
