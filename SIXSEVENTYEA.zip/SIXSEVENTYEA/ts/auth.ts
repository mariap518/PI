export type UserRole = "cliente" | "agente" | "admin";

export interface AuthUser {
  id: string;
  name: string;
  email: string;
  username?: string;
  role: UserRole;
  empresa?: string;
  cc?: string;
  phone?: string;
  city?: string;
  points?: number;
  reservations?: any[];
  favorites?: number[];
  position?: string;
  lifetimePoints?: number;
  coupons?: Coupon[];
}

export interface Coupon { code: string; label: string; percent: number; cost: number; date: string; used: boolean }

/** Datos del formulario de registro (la contraseña solo viaja al servidor, nunca se guarda en el navegador) */
export interface RegisterInput {
  name: string; email: string; username?: string; password: string; role: "cliente" | "agente";
  empresa?: string; cc?: string; phone: string; city: string;
}

export type LoginResult = { user: AuthUser } | { needsCode: "agent" | "admin"; empresa?: string };

/** Empresas de agentes. Los códigos de acceso viven solo en el servidor (server/auth-config.mjs). */
export const AGENT_COMPANIES = ["Uceva", "SENA"];

/** Error del servidor; `field` indica el campo del formulario al que corresponde */
export class ApiError extends Error {
  field?: string;
  constructor(message: string, field?: string) { super(message); this.field = field; }
}

const API = "/api";

async function api<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(API + path, { headers: { "Content-Type": "application/json" }, ...init });
  if (!res.ok) {
    const body = await res.json().catch(() => ({} as { error?: string; field?: string }));
    throw new ApiError(body.error ?? `${init?.method ?? "GET"} ${path} → ${res.status}`, body.field);
  }
  if (res.status === 204) return undefined as T;
  return res.json() as Promise<T>;
}

let currentUser: AuthUser | null = null;
let usersDB: AuthUser[] = [];

/** Administrador: todos los usuarios. Agente: id y empresa de los agentes. Cliente: solo él mismo. */
async function loadUsers() {
  if (!currentUser) { usersDB = []; return; }
  usersDB = currentUser.role === "cliente" ? [currentUser] : await api<AuthUser[]>("/users").catch(() => [currentUser!]);
}

/** Recupera la sesión (cookie) desde Neon antes de montar la app */
export async function initAuth() {
  currentUser = (await api<{ user: AuthUser | null }>("/auth/me")).user;
  await loadUsers();
}

export async function registerUser(input: RegisterInput): Promise<void> {
  await api("/auth/register", { method: "POST", body: JSON.stringify(input) });
}

/** Agentes y administradores deben enviar además su código: la primera llamada responde `needsCode` */
export async function loginUser(identifier: string, password: string, code?: string): Promise<LoginResult> {
  const r = await api<{ user?: AuthUser; needsCode?: "agent" | "admin"; empresa?: string }>("/auth/login", {
    method: "POST", body: JSON.stringify({ identifier, password, code }),
  });
  if (r.needsCode) return { needsCode: r.needsCode, empresa: r.empresa };
  currentUser = r.user!;
  await loadUsers();
  return { user: currentUser };
}

export function getCurrentUser() {
  return currentUser;
}

export function logout() {
  currentUser = null;
  usersDB = [];
  api("/auth/logout", { method: "POST" }).catch(() => {});
}

export function getUsers() {
  return [...usersDB];
}

// Los cambios se envían a Neon de uno en uno, en orden
let pending: Promise<unknown> = Promise.resolve();

function mergeLocal(patch: Partial<AuthUser>) {
  currentUser = { ...currentUser!, ...patch };
  const i = usersDB.findIndex(u => u.id === currentUser!.id);
  if (i >= 0) usersDB[i] = currentUser; else usersDB.push(currentUser);
}

/** Actualiza el usuario al instante en pantalla y lo guarda en Neon en segundo plano (puntos, favoritos, reservas…). */
export function updateUser(patch: Partial<AuthUser>): boolean {
  if (!currentUser) return false;
  mergeLocal(patch);
  const { id, role, ...body } = patch;
  pending = pending
    .then(() => api<AuthUser>("/auth/me", { method: "PUT", body: JSON.stringify(body) }))
    .catch(err => console.error("No se pudo guardar en Neon:", err));
  return true;
}

/** Guarda el perfil esperando al servidor. Devuelve el mensaje de error o null si todo salió bien. */
export async function saveProfile(patch: Partial<AuthUser>): Promise<string | null> {
  if (!currentUser) return "Tu sesión expiró. Inicia sesión de nuevo.";
  try {
    await pending;
    const { id, role, ...body } = patch;
    const updated = await api<AuthUser>("/auth/me", { method: "PUT", body: JSON.stringify(body) });
    mergeLocal(updated);
    return null;
  } catch (err) {
    return (err as Error).message;
  }
}

/** Cambia la contraseña (el servidor verifica la actual). Devuelve el mensaje de error o null. */
export async function changePassword(current: string, next: string): Promise<string | null> {
  try {
    await pending;
    await api("/auth/me", { method: "PUT", body: JSON.stringify({ currentPassword: current, newPassword: next }) });
    return null;
  } catch (err) {
    return (err as Error).message;
  }
}
